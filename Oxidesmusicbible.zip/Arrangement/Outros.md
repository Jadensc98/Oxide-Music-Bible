#arrangement 
```vid
https://www.youtube.com/watch?v=M1ObgCybi_Y
```

## What is it?
Because there’s a separate section in the song structure for the beginning of the song, there’s one for the ending as well. This one is known as the outro. Just like introductions, there are different ways to end a song, such as slowly fading out the song or ending it abruptly.
#daws 

![[b5d5beef4b72aba85bfa3a2cc5e4d771.png]]

There are many DAWs out there to choose from, some more popular and easier to use/learn than others. It all depends on personal taste for choosing which one works best for you. Some people use less popular DAWs simply because of familiarity or niche features that the popular ones may not have available. The most popular DAWs currently are *Logic Pro, Ableton, and FL Studio*.
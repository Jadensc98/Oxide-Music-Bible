## Advice from NEOLYTH
I've asked NEOLYTH for advice on Discord about where to go/what to do when you've reached a point in music production where your base skills can't be improved much further with advice. I've placed a few quotes from him below.

"but when you reach a certain point, you should be looking at getting releases and then its just gonna come down to... whats a good tune? like making the vibiest shit you can then send it off"

I told him that I've found it a bit of a struggle getting releases as a small artist, since labels consider your following. 

"yea so youre gonna need a bit of networking and a little bit of luck. labels are usually backlogged with releases and have already a whole bunch of sick artists on it. you will need to get to know people who are even slightly involved or on the up, write tunes until your skills continue to peak or you land on some very slick productions. kinda put urself out there, easier said than done and a lot of soul searching, like 'how can i write better music' your technique is already getting to the level so thats not gonna be your issue."

"its not just making music and posting it to empty social medias and servers, its more about networking, as in interaction, proving yourself, making some leaps and bounds getting to know people at all levels, not just the dons but the up and comers. working with people, these are the keys once you hit a certain point"

I then asked what he thinks about the importance of sounding unique.

"You should be trending towards sounding unique of course. firstly, you're already unique sonic fingerprint and all that.  as rabbit (someone else in server) says, dont force it as in dont copy blindly then youll be a worse version of someone else but also, all the techniques, all the chords, reese, drum patterns etc has all been done before so to come out with something blindingly new is next to impossible and can take years, but as you know, some tunes even though they are just a vocal, reese and some drums, some combinations are just that good. so its about landing the vibiest shit you can, not trying to be necessarily unique, a hits a hit. the right chords, with the right vocal and you're made"

After this, I said "got it, that makes sense. Last question i can think of while youre here, i feel like even when im advertising my releases i still feel like its a bit of releasing into the void, i get a decent amount of listens and follows from releases but i feel like im not getting fans, like 1-2k plays on a track with 1-2 comments is wild to me"

"the way i saw it, coming from someone with 0 social media presence self releasing is next to impossible anyway. its all about engagement and the only way to get engagement if you dont have any is to leverage it. thats why getting on a label and then a youtube channel or other media outlets will get that kind of engagement. i dont see any other way, other than paying google ads lol. also by networking and putting the time in with other peoples music, you might get some people engaging back"

"You wont get in the door by messaging the best of the best obviously you have to start smaller, then prove yourself. like, if u get a good opportunity you have to fucking nail it and because you did such outstanding work people will be like.. yo i saw what you did there man good job. like you have to nail the opportunities as they come. i think it works that way like any sportsman on a penalty shootout, if they perform well, everyone is gonna be like damn that was so good and now hes getting sponsorship deals. thats how i see it anyway."

Check out his music here: https://soundcloud.com/Neolyth
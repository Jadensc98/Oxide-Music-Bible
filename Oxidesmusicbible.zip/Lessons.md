 - What processing do you use for vocals? Do you have separate methods for mixing vocals in the intro vs. the drop?
 - What does your mastering chain consist of?
 - What resources have you learned? What have you learned from the most?
 - How do you recommend shifting more attention from Soundcloud over to Spotify?
 - Go over the Serpent of Old remix
 - For songs like Paul's Dream and Duel of the Fates, how are you developing the orchestral sounds? 

## Notes
- edison blur for vocal reverb
- vocalsynth 2
- MRingmodulatorMB or khs ring mod for crucnh
- archetype gojira neural dsp
- layering different vocals
#mastering 

## Personal Notes

- Ozone Vintage Limiter on the master seems to be good. Try using Pro-L with Modern Loud preset and +4 or x8 oversampling first then Ozone Vintage Limiter after (Analog Glue preset with Modern mode).
#mixing 
```vid
https://www.youtube.com/watch?v=O-VzlSIUHGc&list=WL&index=9&t=56s&pp=gAQBiAQB
```

#sounddesign

when making monophonic sounds like basses or leads, it's typically better to have the unison set to an odd number (i.e. 15 instead of 16) in order to have a clearer fundamental frequency, and let 100% of the harmonics come from the detuned unison signals instead of having two main signals with the detunes on the side8